./objects/irq_rit.o: Source\RIT\IRQ_RIT.c \
  C:\Keil_v5\ARM\PACK\Keil\LPC1700_DFP\2.7.1\Device\Include\LPC17xx.h \
  Source\CMSIS_core\core_cm3.h \
  C:\Keil_v5\ARM\PACK\Keil\LPC1700_DFP\2.7.1\Device\Include\system_LPC17xx.h \
  Source\RIT\RIT.h Source\RIT\..\led\led.h Source\RIT\..\timer\timer.h \
  Source\RIT\..\GLCD\GLCD.h
