#include "button.h"
#include "lpc17xx.h"

#include "../led/led.h"

extern unsigned char lfsr_step(unsigned char current_state, unsigned char taps, int *output_bit);
extern volatile unsigned char seed; 
extern volatile unsigned char state;
extern unsigned char taps;

void delay_ms(uint32_t count) {
    volatile uint32_t i;
    for(i = 0; i < (count * 3000); i++); 
}

void EINT0_IRQHandler (void)	  
{
	taps ^= 0x01;	
	LED_Out(taps);
	delay_ms(50);
	LPC_SC->EXTINT |= (1 << 0);
}

void EINT1_IRQHandler (void)	  
{
	taps = taps << 1;
	LED_Out(taps);
	delay_ms(50);
	LPC_SC->EXTINT |= (1 << 1);
}

void EINT2_IRQHandler (void)	  
{
	int length_count = 0;
	int output_bit = 0;
	state = seed;
	do {
		state = lfsr_step(state, taps, &output_bit);
		length_count++;
		} while (state != seed && state != 0);
    LED_Out(length_count);
	delay_ms(50);
	LPC_SC->EXTINT |= (1 << 2);
}


