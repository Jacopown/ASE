#include <stdio.h>
#include "LPC17xx.H"                    /* LPC17xx definitions                */
#include "led/led.h"
#include "button_EXINT/button.h"

/* Led external variables from funct_led */
extern unsigned char led_value;					/* defined in funct_led								*/
#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to visible in order for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif

/*funzione esterna importata da lfsr_step.s*/
extern unsigned char lfsr_step(unsigned char current_state, unsigned char taps, int *output_bit);

// Variabili globali
volatile unsigned char seed = 0xAA; // Seed iniziale (10101010)
volatile unsigned char state = 0xAA;
unsigned char taps = 0x00;          // Esempio taps (10001101) - Cambia secondo esercizio

/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
int main (void) {
	
  SystemInit();  												/* System Initialization (i.e., PLL)  */
  LED_init();                           /* LED Initialization                 */
  BUTTON_init();												/* BUTTON Initialization              */
	
	
	/*accendo i led con lo stato iniziale*/
	LED_Out(taps);

  while (1) {                           /* Loop forever                       */	
  }

}