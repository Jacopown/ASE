	AREA asm_func, CODE, READONLY
    EXPORT lfsr_step

lfsr_step

    AND     R3, R0, #1          ; Mask R0 to get bit 0
    STR     R3, [R2]            ; Store this bit into the address held in R2 (*output_bit)

    AND     R3, R0, R1          ; R3 = current_state & taps. Only tapped bits remain.

    EOR     R3, R3, R3, LSR #4  ; XOR bits [7:4] with [3:0]
    EOR     R3, R3, R3, LSR #2  ; XOR result bits [3:2] with [1:0]
    EOR     R3, R3, R3, LSR #1  ; XOR result bit [1] with [0]
    AND     R3, R3, #1          ; Isolate the LSB. R3 is now the Feedback Bit (0 or 1).

    LSR     R0, R0, #1          ; Shift current_state RIGHT by 1
                                ; (Bits move 7->6, ... 1->0. Old bit 0 is discarded)

    LSL     R3, R3, #7          ; Move feedback bit from pos 0 to pos 7 (0x80)
    ORR     R0, R0, R3          ; Insert the feedback bit into the MSB

    UXTB    R0, R0              ; Zero-extend byte (ensure output is 8-bit)

    BX      LR                  ; Return to caller
    END